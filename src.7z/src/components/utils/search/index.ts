export const getSearchInput = (searchStringData:string) => {
    return "'" + searchStringData;
}