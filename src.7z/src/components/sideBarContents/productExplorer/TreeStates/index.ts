export enum ProductTreeStates {
    Tree,
    Search,
    DisplayModes
}
