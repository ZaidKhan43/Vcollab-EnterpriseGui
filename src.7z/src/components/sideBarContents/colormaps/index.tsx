export default function ColorMaps(){
    return ( <div>ColorMaps</div>)
}