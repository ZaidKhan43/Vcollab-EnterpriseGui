export default function ClipPlanes(){
    return ( <div>ClipPlanes</div>)
}