export default function Views(){
    return ( <div>Views</div>)
}