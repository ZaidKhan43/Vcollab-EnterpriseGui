declare module '@fseehawer/react-circular-slider'
declare module 'react-numeric-input'
declare module 'react-color'